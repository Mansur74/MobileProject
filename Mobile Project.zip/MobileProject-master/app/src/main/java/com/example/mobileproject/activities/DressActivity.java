package com.example.mobileproject.activities;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.mobileproject.R;
import com.example.mobileproject.adapters.SuitAdapter;
import com.example.mobileproject.models.Suit;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DressActivity extends AppCompatActivity {
    ListView suitList;
    List<Suit> suits;
    SuitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dress);

        suitList = findViewById(R.id.dress_list);
        suits = new ArrayList<>();

        adapter = new SuitAdapter(DressActivity.this, suits);
        suitList.setAdapter(adapter);

        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://www.jsonkeeper.com/b/XPAY";
        JsonObjectRequest
                jsonObjectRequest
                = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                       // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_LONG).show();

                        try {
                            for(int i=0; i <  response.getJSONArray("dress").length(); i++)
                            {
                                JSONObject object = response.getJSONArray("dress").getJSONObject(i);
                                String brand = object.getString("brand");
                                String gender = object.getString("gender");
                                String color = object.getString("color");
                                String date = object.getString("rentPrice");
                                String url = object.getString("url");
                                Suit suit = new Suit(brand, "bos",gender, color, date,url);
                                suits.add(suit);
                            }

                            adapter = new SuitAdapter(DressActivity.this, suits);
                            suitList.setAdapter(adapter);

                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        queue.add(jsonObjectRequest);



    }


}