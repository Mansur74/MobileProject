package com.example.mobileproject.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.mobileproject.R;
import com.example.mobileproject.models.Suit;

import java.util.List;

public class SuitAdapter extends ArrayAdapter<Suit> {

    private final LayoutInflater inflater;
    private Suit suit;

    public SuitAdapter(Activity context, List<Suit> views) {
        super(context, 0, views);
        inflater = LayoutInflater.from(context);


    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Suit suitData = getItem(position);
        View currencyView = inflater.inflate(R.layout.list_item_suit ,null, true);

        TextView brand = (TextView) currencyView.findViewById(R.id.brand);
        TextView name = (TextView) currencyView.findViewById(R.id.name);
        TextView gender = (TextView) currencyView.findViewById(R.id.gender);
        TextView color = (TextView) currencyView.findViewById(R.id.color);
        TextView date = (TextView) currencyView.findViewById(R.id.date);
        ImageView image = (ImageView) currencyView.findViewById(R.id.suit_imageView);
      //String y = "https://cdn.shopify.com/s/files/1/0692/4255/products/Black-Suit-2_13dc0fca-689d-4d7f-92a1-433904f41d13_800x.jpg";
        String xx =suitData.getImgURL();




       // url.setText((suitData.getImgURL()));
        brand.setText(suitData.getBrand());
        name.setText(suitData.getName());
        gender.setText(suitData.getGender());
        color.setText(suitData.getColor());
        date.setText(suitData.getDate());
        Glide.with(getContext()).load(xx).into(image);

        return currencyView;
    }

}
