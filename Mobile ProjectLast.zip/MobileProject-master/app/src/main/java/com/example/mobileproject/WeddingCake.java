package com.example.mobileproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.mobileproject.adapters.CakeAdapter;
import com.example.mobileproject.adapters.SuitAdapter;
import com.example.mobileproject.models.cake;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WeddingCake extends AppCompatActivity {
    ListView cakeList;
    List<cake> cake;
    CakeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wedding_cake);

        cakeList = findViewById(R.id.cakes_list);
        cake = new ArrayList<>();

        adapter = new CakeAdapter(WeddingCake.this, cake);
        cakeList.setAdapter(adapter);

        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://jsonkeeper.com/b/M04D";
        JsonObjectRequest
                jsonObjectRequest
                = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_LONG).show();

                        try {
                            for(int i=0; i <  response.getJSONArray("cake").length(); i++)
                            {
                                JSONObject object = response.getJSONArray("cake").getJSONObject(i);
                                String flavor = object.getString("flavor");
                                String feeds = object.getString("feeds");
                                String price = object.getString("price");


                                cake ccake = new cake(flavor, feeds, price);
                                cake.add(ccake);
                            }

                            adapter = new CakeAdapter(WeddingCake.this, cake);
                            cakeList.setAdapter(adapter);

                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        queue.add(jsonObjectRequest);



    }


}