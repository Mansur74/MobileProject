package com.example.mobileproject.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.mobileproject.R;
import com.example.mobileproject.models.cake;

import java.util.List;


public class CakeAdapter extends ArrayAdapter<cake> {

    private final LayoutInflater inflater;

    public CakeAdapter(Activity context, List<cake> views) {
        super(context, 0, views);
        inflater = LayoutInflater.from(context);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        cake cakeData = getItem(position);
        View currencyView = inflater.inflate(R.layout.cake_list ,null, true);

        TextView flavor = (TextView) currencyView.findViewById(R.id.flavor_value);
        TextView feeds = (TextView) currencyView.findViewById(R.id.feeds_value);
        TextView price = (TextView) currencyView.findViewById(R.id.price_vale);
        ImageView image = (ImageView) currencyView.findViewById(R.id.cake_url);

        flavor.setText(cakeData.getFlavor());
        feeds.setText(cakeData.getFeeds());
        price.setText(cakeData.getPrice());
        Glide.with(getContext()).load("https://cdn.shopify.com/s/files/1/0692/4255/products/Black-Suit-2_13dc0fca-689d-4d7f-92a1-433904f41d13_800x.jpg").into(image);

        return currencyView;
    }

}
