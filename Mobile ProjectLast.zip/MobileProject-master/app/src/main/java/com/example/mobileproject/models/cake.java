package com.example.mobileproject.models;



public class cake {
    String flavor, feeds, price;

    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }

    public String getFlavor() {
        return flavor;
    }

    public String getFeeds() {
        return feeds;
    }

    public String getPrice() {
        return price;
    }

    public void setFeeds(String feeds) {
        this.feeds = feeds;
    }





    public void setPrice(String price) {
        this.price = price;
    }

    public cake(String flavor, String feeds, String price)
    {
        this.flavor = flavor;
        this.feeds = feeds;
        this.price = price;


    }


}

